const suits = ['♠', '♥', '♦', '♣'];
const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
let deck = [];

function createDeck() {
  deck = [];
  suits.forEach(suit => {
    values.forEach(value => {
      deck.push({suit, value});
    });
  });
}

function shuffleDeck() {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
}

function createCard(card, faceUp = false, top = 0) {
  const div = document.createElement('div');
  div.className = 'card';
  div.textContent = card.value + card.suit;
  div.dataset.suit = card.suit;
  div.dataset.value = card.value;
  div.dataset.faceUp = faceUp;
  div.style.top = top + 'px';
  if (card.suit === '♥' || card.suit === '♦') {
    div.classList.add('red');
  }
  if (!faceUp) {
    div.classList.add('back');
  }
  div.draggable = faceUp;
  div.addEventListener('click', flipOrPick);
  div.addEventListener('dragstart', dragStart);
  return div;
}

function setupGame() {
  document.querySelectorAll('.pile').forEach(pile => pile.innerHTML = '');
  createDeck();
  shuffleDeck();
  let cardIndex = 0;
  const tableau = document.querySelectorAll('.tableau');

  tableau.forEach((pile, i) => {
    for (let j = 0; j <= i; j++) {
      const faceUp = (j === i);
      const card = createCard(deck[cardIndex++], faceUp, j * 30);
      pile.appendChild(card);
    }
  });

  const stock = document.getElementById('stock');
  while (cardIndex < deck.length) {
    const card = createCard(deck[cardIndex++]);
    stock.appendChild(card);
  }
}

function flipOrPick(e) {
  const card = e.currentTarget;
  if (card.parentElement.id === 'stock') {
    drawFromStock();
  } else if (card.classList.contains('back')) {
    card.classList.remove('back');
    card.dataset.faceUp = "true";
    card.draggable = true;
  }
}

function drawFromStock() {
  const stock = document.getElementById('stock');
  const waste = document.getElementById('waste');
  if (stock.children.length === 0) {
    while (waste.children.length > 0) {
      const card = waste.lastChild;
      waste.removeChild(card);
      card.classList.add('back');
      card.dataset.faceUp = "false";
      card.draggable = false;
      stock.appendChild(card);
    }
    return;
  }
  const card = stock.lastChild;
  stock.removeChild(card);
  card.classList.remove('back');
  card.dataset.faceUp = "true";
  card.draggable = true;
  waste.appendChild(card);
}

function dragStart(e) {
  const dragged = e.target;
  if (dragged.dataset.faceUp !== "true") {
    e.preventDefault();
    return;
  }
  e.dataTransfer.setData('text/plain', JSON.stringify({
    value: dragged.dataset.value,
    suit: dragged.dataset.suit
  }));
  dragged.classList.add('dragging');
}

function allowDrop(e) {
  e.preventDefault();
}

function dropCard(e) {
  e.preventDefault();
  const target = e.currentTarget;
  const data = JSON.parse(e.dataTransfer.getData('text/plain'));
  const card = document.querySelector(`.card.dragging`);
  card.classList.remove('dragging');

  if (target.classList.contains('foundation')) {
    if (canMoveToFoundation(target, data)) {
      target.appendChild(card);
      card.style.top = '0px';
    }
  } else {
    if (canMoveToTableau(target, data)) {
      const offset = target.children.length * 30;
      card.style.top = offset + 'px';
      target.appendChild(card);
    }
  }

  flipLastCard(e);
}

function canMoveToFoundation(pile, data) {
  const top = pile.lastElementChild;
  if (!top) {
    return data.value === 'A';
  }
  return data.suit === pile.dataset.suit && getValueIndex(data.value) === getValueIndex(top.dataset.value) + 1;
}

function canMoveToTableau(pile, data) {
  const top = Array.from(pile.children).filter(c => c.dataset.faceUp === "true").pop();
  if (!top) {
    return data.value === 'K';
  }
  return isOppositeColor(data.suit, top.dataset.suit) && getValueIndex(data.value) === getValueIndex(top.dataset.value) - 1;
}

function getValueIndex(val) {
  return values.indexOf(val);
}

function isOppositeColor(suit1, suit2) {
  const red = ['♥', '♦'];
  const black = ['♠', '♣'];
  return (red.includes(suit1) && black.includes(suit2)) || (black.includes(suit1) && red.includes(suit2));
}

function flipLastCard(e) {
  const pile = e.currentTarget;
  const faceDown = Array.from(pile.children).filter(c => c.classList.contains('back'));
  if (faceDown.length > 0) {
    const lastFaceDown = faceDown[faceDown.length - 1];
    if (!Array.from(lastFaceDown.nextElementSibling || []).length) {
      lastFaceDown.classList.remove('back');
      lastFaceDown.dataset.faceUp = "true";
      lastFaceDown.draggable = true;
    }
  }
}

document.querySelectorAll('.pile').forEach(pile => {
  pile.addEventListener('dragover', allowDrop);
  pile.addEventListener('drop', dropCard);
});

document.getElementById('restart').addEventListener('click', setupGame);

setupGame();
